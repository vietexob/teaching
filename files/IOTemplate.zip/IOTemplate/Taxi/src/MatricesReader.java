import java.io.*;
import java.util.*;
/**
 * Created by khoi on 2/29/2016.
 */
public class MatricesReader{
    private int getEdgeIndex(int nodeIndex1, int nodeIndex2){
        //sort the para
        if(nodeIndex1 > nodeIndex2){
            int cache = nodeIndex1;
            nodeIndex1 = nodeIndex2;
            nodeIndex2 = cache;
        }
        else if(nodeIndex1 == nodeIndex2) return 0;

        //return value
        Integer value = edgeIndexMatrix.get(nodeIndex1).get(nodeIndex2);
        if(value != null) return value;
        else return 0;
    }

    private int getMaxSpeed(int nodeIndex1, int nodeIndex2){
        //sort the para
        if(nodeIndex1 > nodeIndex2){
            int cache = nodeIndex1;
            nodeIndex1 = nodeIndex2;
            nodeIndex2 = cache;
        }
        else if(nodeIndex1 == nodeIndex2) return 0;

        //return value
        Integer value = maxSpeedMatrix.get(nodeIndex1).get(nodeIndex2);
        if(value != null) return value;
        else return 0;
    }

    private int getSegLength(int nodeIndex1, int nodeIndex2){
        //sort the para
        if(nodeIndex1 > nodeIndex2){
            int cache = nodeIndex1;
            nodeIndex1 = nodeIndex2;
            nodeIndex2 = cache;
        }
        else if(nodeIndex1 == nodeIndex2) return 0;

        //return value
        Integer value = segmentLengthMatrix.get(nodeIndex1).get(nodeIndex2);
        if(value != null) return value;
        else return 0;
    }

    public static void main(String[] args){
        MatricesReader m = new MatricesReader("");
        System.out.println(m.getEdgeIndex(1,3));
        System.out.println(m.getMaxSpeed(3,1));
        System.out.println(m.getSegLength(3,1));
    }

    /////// Ignorable ///////
    final String EDGE_INDEX_FILE_NAME = "edge_idx_matrix";
    final String MAX_SPEED_FILE_NAME = "max_speed_matrix";
    final String SEG_LEN_FILE_NAME = "seg_len_matrix";
    private HashMap<Integer, HashMap<Integer, Integer>> edgeIndexMatrix = new HashMap<>();
    private HashMap<Integer, HashMap<Integer, Integer>> maxSpeedMatrix = new HashMap<>();
    private HashMap<Integer, HashMap<Integer, Integer>> segmentLengthMatrix = new HashMap<>();

    public MatricesReader(String matricesFolderPath){
        try{
            File f1 = new File(matricesFolderPath + EDGE_INDEX_FILE_NAME + ".csv");
            File f2 = new File(matricesFolderPath + MAX_SPEED_FILE_NAME + ".csv");
            File f3 = new File(matricesFolderPath + SEG_LEN_FILE_NAME + ".csv");

            BufferedReader br = null;

            //read edge index file
            br = new BufferedReader(new FileReader(f1));
            readCSV(br, edgeIndexMatrix);

            //read max speed file
            br = new BufferedReader(new FileReader(f2));
            readCSV(br, maxSpeedMatrix);

            //read seg len file
            br = new BufferedReader(new FileReader(f3));
            readCSV(br, segmentLengthMatrix);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void readCSV(BufferedReader br, HashMap<Integer, HashMap<Integer, Integer>> hashMapMatrix){
        try{
            //skip the header
            br.readLine();

            for(int i = 0; i < 9948; i++){
                String[] s = br.readLine().split(",");
                HashMap<Integer,Integer> h = new HashMap<>();

                for(int j = i + 1 ; j < 9948; j++){
                    int value = (int)Double.parseDouble(s[j]);
                    if(value > 0) h.put(j, value);
                }

                hashMapMatrix.put(i, h);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
